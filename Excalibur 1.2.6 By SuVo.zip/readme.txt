1) Install Excalibur Installer
2) Run Add Key Reg File
3) Open Premiere Pro :) Enjoy